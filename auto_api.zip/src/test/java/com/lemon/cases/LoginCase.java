package com.lemon.cases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.Test;

public class LoginCase {
	
	@Test(enabled = false)
	public void testByGet() {
		/*
		 * 1、创建request连接.
		 * 2、填写url和参数
		 * 3、如果有参添加参数
		 * 4、发送请求
		 * 5、获取响应报文
		 * 6、格式化
		 * 7、在控制台输出报文
		 */
		//1、创建request连接.
		//2、填写url和参数
		String url = "http://test.lemonban.com/futureloan/mvc/api/member/register";
		String parameters = "mobilephone=13212312392&pwd=123123";
		url = url + "?" + parameters;
		HttpGet get = new HttpGet(url);
		//4、发送请求	
		//HttpClients是一个工具类，用来服务HttpClient类的。
		//以后看见某个类名字是另外一个类的名称+s，说明他就是一个工具类.
		//f4 查看一个类的继承树
		HttpClient client = HttpClients.createDefault();
		//处理异常两种方式：抛出去（交给别人处理，自己不处理），捕获（如果出现了异常，自己立马处理）
		try {
			
			//4.1、发出请求获得响应对象
			HttpResponse response = client.execute(get);
			//5、获取响应报文
			//5.1、获取状态码
			//链式编程 相当于下面两行代码
//			int statusCode = response.getStatusLine().getStatusCode();//200 404
			StatusLine statusLine = response.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			//6、格式化
			HttpEntity entity = response.getEntity();
			String result = EntityUtils.toString(entity);
			//6.1、获取头信息
			String allHeaders = Arrays.toString(response.getAllHeaders());
			// ctrl + 2 + l
			System.out.println("响应报文头信息：" + allHeaders);
			System.out.println("状态码：" + statusCode);
			System.out.println("响应报文头报文：" + result);
			
		} catch (IOException e) {
			//IOException 是编译时异常。
			//处理异常的代码。
			e.printStackTrace();
		}
	}
	
	@Test
	public void testByPost() {
		/*
		 * 1、创建request连接.
		 * 2、填写url和参数
		 * 3、如果有参添加参数
		 * 4、发送请求
		 * 5、获取响应报文
		 * 6、格式化
		 * 7、在控制台输出报文
		 */
		//1、创建request连接.
		//2、填写url和参数
		String url = "http://test.lemonban.com/futureloan/mvc/api/member/register";
		HttpPost post = new HttpPost(url);
		//BasicNameValuePair = {mobilephone = 13212312312} {pwd = 123123}
//	 	ArrayList<BasicNameValuePair> params = new ArrayList<>();
//		params.add(new BasicNameValuePair("mobilephone","13217312332"));
//		params.add(new BasicNameValuePair("pwd","123123"));
		//HttpClients是一个工具类，用来服务HttpClient类的。
		//以后看见某个类名字是另外一个类的名称+s，说明他就是一个工具类.
		//f4 查看一个类的继承树
		//2.1创建client对象
		HttpClient client = HttpClients.createDefault();
		//处理异常两种方式：抛出去（交给别人处理，自己不处理），捕获（如果出现了异常，自己立马处理）
		try {
			//3、绑定参数
//			post.setEntity(new UrlEncodedFormEntity(params,"UTF-8"));
			//3.1、设置请求头，以表单的方式提交参数
//			post.setHeader("Content-Type","application/x-www-form-urlencoded");
			post.setEntity(new StringEntity("mobilephone=13212312392&pwd=123123","UTF-8"));
			//4、发送请求	
			//4.1、发出请求获得响应对象
//			HttpHost proxy = new HttpHost("127.0.0.1",8889);
//			HttpResponse response = client.execute(proxy,post);
			HttpResponse response = client.execute(post);
			//5、获取响应报文
			//5.1、获取状态码
			//链式编程 相当于下面两行代码
//			int statusCode = response.getStatusLine().getStatusCode();//200 404
			StatusLine statusLine = response.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			//6、格式化
			HttpEntity entity = response.getEntity();
			String result = EntityUtils.toString(entity);
			//6.1、获取头信息
			String allHeaders = Arrays.toString(response.getAllHeaders());
			// ctrl + 2 + l
			System.out.println("响应报文头信息：" + allHeaders);
			System.out.println("状态码：" + statusCode);
			System.out.println("响应报文头报文：" + entity);
			System.out.println("响应报文头报文：" + result);
			
		} catch (IOException e) {
			//IOException 是编译时异常。
			//处理异常的代码。
			e.printStackTrace();
		}
	}
	
	
}
